package com.example.demo.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Generated API Documentation")
                .version("1.0.0")
                .description("Auto-generated API documentation from PRD")
                .contact(new Contact()
                    .name("Your Organization")
                    .url("https://example.com")));
    }
}